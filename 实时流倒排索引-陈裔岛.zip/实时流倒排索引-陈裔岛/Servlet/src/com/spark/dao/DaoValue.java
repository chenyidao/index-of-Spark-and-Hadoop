package com.spark.dao;
import redis.clients.jedis.Jedis;
public class DaoValue {
		public static String getValue(String key){
			Jedis je = new Jedis("172.17.11.166", 6379);
			je.auth("123456");
			je.connect();
			je.select(0);
			String value = je.get(key);
			String[]s = value.split(";");
			String result = "�����ùؼ��ʵ�URL-�ʵĸ���"+"\\n";
			
			for(String ss:s){
				result+=ss+"\\n";
			}
			je.close();
			return result;
		}
	/*	public static void main(String[] args) {
			String str = DaoService.getValue("һ");
			System.out.println(str);
		}*/
	}
