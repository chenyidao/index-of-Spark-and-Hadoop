package sparkStreamingKafka

import kafka.serializer.StringDecoder
import org.apache.spark.streaming._
import org.apache.spark._
import redis.clients.jedis.Jedis
import org.apache.spark.streaming.dstream._

import org.apache.spark.streaming.kafka.KafkaUtils

object KafkaSparkConsumer {
  def main(args: Array[String]) {
    System.setProperty("hadoop.home.dir", "C:\\hadoop\\hadooop_install_env\\hadoop-2.7.6")
    
    val sparkConf = new SparkConf().setMaster("local[*]").setAppName("test")
    val scc = new StreamingContext(sparkConf, Duration(5000))
    scc.sparkContext.setLogLevel("ERROR")
    scc.checkpoint(".") // 因为使用到了updateStateByKey,所以必须要设置checkpoint
    val topics = Set("test") //我们需要消费的kafka数据的topic
    val brokers = "172.17.11.140:9092,172.17.11.142:9092,172.17.11.143:9092"
    val kafkaParam = Map[String, String](
      "zookeeper.connect" -> "172.17.11.140:2181,172.17.11.142:2181,172.17.11.143:2181",
      "metadata.broker.list" -> brokers, // kafka的broker list地址
      "serializer.class" -> "kafka.serializer.StringEncoder")

    val stream: InputDStream[(String, String)] = createStream(scc, kafkaParam, topics)
    
/*    var s = stream.map(_._2).flatMap(_.split(";"))
    var url = s.map(_._2)
      .map(r => (r, 1)) // 每个单词映射成一个pair
      .updateStateByKey[Int](updateFunc) // 用当前batch的数据区更新已有的数据
//      .print() // 打印前10个数据
    scc.start() // 真正启动程序
    scc.awaitTermination() //阻塞等待
  }
    */
    /*stream.map(_._2) //取出value
      .flatMap(_.split(" ")) // 将字符串使用空格分隔
      .map(r => (r, 1)) // 每个单词映射成一个pair
      .updateStateByKey[Int](updateFunc) // 用当前batch的数据区更新已有的数据
//      .print() // 打印前10个数据
    scc.start() // 真正启动程序
    scc.awaitTermination() //阻塞等待
  }*/
    var url = stream.map(_._2).map(word=>(word,1)).reduceByKey(_+_).map(x=>{ //取每个相同的
          {var a = x._1.substring(0,x._1.indexOf(";"))
            var b = x._1.substring(x._1.indexOf(";")+1,x._1.length())+"－"+x._2
            (a,b)
          }
        }).reduceByKey((a,b)=>a+","+b)
//     url.print()
     //结果进入redis缓存
    var je: Jedis = null;
    try {
      url.foreachRDD(rdd => {
        rdd.foreachPartition(partition => {
          je = new Jedis("172.17.11.166", 6379)
          je.auth("123456")
          je.connect()
          je.select(0)
          partition.foreach(y => {
            val value = je.get(y._1)
            if (value == null || "".equals(value) || value.length() == 0) {
              je.set(y._1, String.valueOf(y._2))
            } else {
              je.set(y._1, String.valueOf(y._2 + ";"+value))
            }
          })
        })
      })
    } catch {
      case e =>
        e.printStackTrace()
    } finally {
      if (je != null) {
        je.close()
      }
    }
    scc.start() // 真正启动程序
    scc.awaitTermination() //阻塞等待
  }

  /*val updateFunc = (currentValues: Seq[Int], preValue: Option[Int]) => {
    val curr = currentValues.sum
    val pre = preValue.getOrElse(0)
    Some(curr + pre)
  }*/
  /**
   * 创建一个从kafka获取数据的流.
   */

  def createStream(scc: StreamingContext, kafkaParam: Map[String, String], topics: Set[String]) = {
    KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](scc, kafkaParam, topics)
  }

}
