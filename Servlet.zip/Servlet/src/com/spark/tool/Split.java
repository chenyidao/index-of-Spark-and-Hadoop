package com.spark.tool;

import java.util.ArrayList;

public class Split {
	public static ArrayList<String> splitUrl(String str)
	{
		ArrayList<String>list = new ArrayList<>();
		String[] ss = str.split(";");
		for(String s:ss)
		{
			list.add(s);
		}
		return list;
	}
}
