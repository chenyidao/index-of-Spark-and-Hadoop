package com.spark.service;
import java.util.Iterator;
import java.util.Set;

import redis.clients.jedis.Jedis;

public class Relation {
	
		public static String getRelationWord(String k){
			Jedis je = new Jedis("172.17.11.166", 6379);
			je.auth("123456");
			je.connect();
			je.select(0);
//			Map<String,String>map=null;
			int i = 0;
			String result = "�����ùؼ��ʵĹؼ���:URL-�ʵĸ���(ֻ��ʾǰ10��)"+"\\n";
			//��ѯredis�����е�key
			Set<String> keys =je.keys("*");
			Iterator<String> it =keys.iterator();
			while(it.hasNext()) {
				String key = it.next();
				if((key.contains(k)) && (!key.equals(k))){
					result+=key+":"+je.get(key)+";"+"\\n";
//					System.out.println(result);
					i++;
				}
				if(i>=10){
					break;
				}
				
				System.out.println(it.next());
			}
			je.close();
			
//			System.out.println(result);
			return result;
			
		}
	/*	public static void main(String[] args) {
			DaoRelation.getRelationWord("̸");
		}*/


	}

