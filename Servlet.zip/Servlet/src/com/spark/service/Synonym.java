package com.spark.service;

import com.spark.dao.DaoGetSynonym;

import redis.clients.jedis.Jedis;

 //��db0�л�ȡvalueֵ
public class Synonym {
	
	public static String getSynonym(String k){
		String str = DaoGetSynonym.getSnnValue(k);
		String[] keys = str.split(" ");
		String result = "�ùؼ��ʵĽ����-��Ӧ��URL-�ʵĸ���"+"\\n";
		Jedis je = new Jedis("172.17.11.166", 6379);
		je.auth("123456");
		je.connect();
		je.select(0);
		
		for(String key:keys){
			result+=key+"-"+je.get(key)+"\\n";
		}
		je.close();
		return result;
		
	}
}
