package com.spark.dao;

import redis.clients.jedis.Jedis;

public class DaoGetSynonym {
	
	//��db1�л�ȡ�����
	public static String getSnnValue(String k){
	Jedis je = new Jedis("172.17.11.166", 6379);
	je.auth("123456");
	je.connect();
	je.select(1);
//	Map<String,String>map=null;
//	String result = "";
	//��ѯredis�����е�key
//	Set<String> keys =je.keys("*");
//	Iterator<String> it =keys.iterator();
	String keys = je.get(k);
	je.close();
	return keys;
	}
}
