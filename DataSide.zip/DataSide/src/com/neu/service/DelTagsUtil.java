package com.neu.service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import com.huaban.analysis.jieba.JiebaSegmenter;

public class DelTagsUtil {

	public static ArrayList<String> delTags(ArrayList<String>list) throws FileNotFoundException, IOException, InterruptedException {
		
		ArrayList<String> ls = new ArrayList<String>();
//		    String everyLine = "";
//		String filelocation = "D:\\data\\rtdata\\file";
//		int i ;
		//List<String> allString = new ArrayList<>();
		for(int i=0;i<list.size();i++) {
//			System.out.println(line);
//						getURLFile(line, filelocation + i + ".txt",i);
			ls.add(getURLFile(list.get(i)));
			Thread.sleep(3);
		}
		return ls;
	}

	public static String getURLFile(String urlname) {
		
		
		String urlString = "";
		URL url = null;
		
		try {
			url = new URL(urlname);
//			File fp = new File(filelocation);
//			OutputStream os = new FileOutputStream(fp);
//			OutputStreamWriter osw = new OutputStreamWriter(os);
//			URLConnection conn = url.openConnection();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			if (conn.getResponseCode() == 200) {
			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String current = null;
			while ((current = in.readLine()) != null) {
				current = removeHtmlTag(current);
				urlString += current;
			}
			urlString=url+"-"+urlString;
//			osw.write(url + "-");
//			osw.write(urlString);
//			osw.flush();
//			osw.close();
		}
		}catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
//		System.out.println(urlString);
		return urlString;
		
	}

	public static String removeHtmlTag(String inputString) {
		if (inputString == null)
			return null;
		String htmlStr = inputString;
		String textStr = "";
		java.util.regex.Pattern p_script;
		java.util.regex.Matcher m_script;
		java.util.regex.Pattern p_style;
		java.util.regex.Matcher m_style;
		java.util.regex.Pattern p_html;
		java.util.regex.Matcher m_html;
		java.util.regex.Pattern p_special;
		java.util.regex.Matcher m_special;
		try {
			String regEx_script = "<[\\s]*?script[^>]*?>[\\s\\S]*?<[\\s]*?\\/[\\s]*?script[\\s]*?>";
			String regEx_style = "<[\\s]*?style[^>]*?>[\\s\\S]*?<[\\s]*?\\/[\\s]*?style[\\s]*?>";
			String regEx_html = "<[^>]+>";
			String regEx_special = "\\&[a-zA-Z]{1,10};";

			p_script = Pattern.compile(regEx_script, Pattern.CASE_INSENSITIVE);
			m_script = p_script.matcher(htmlStr);
			htmlStr = m_script.replaceAll("");

			p_style = Pattern.compile(regEx_style, Pattern.CASE_INSENSITIVE);
			m_style = p_style.matcher(htmlStr);
			htmlStr = m_style.replaceAll("");

			p_html = Pattern.compile(regEx_html, Pattern.CASE_INSENSITIVE);
			m_html = p_html.matcher(htmlStr);
			htmlStr = m_html.replaceAll("");

			p_special = Pattern.compile(regEx_special, Pattern.CASE_INSENSITIVE);
			m_special = p_special.matcher(htmlStr);
			htmlStr = m_special.replaceAll("");

			String reg = "[^\u4e00-\u9fa5]";
			htmlStr = htmlStr.replaceAll(reg, "");

			JiebaSegmenter segmenter = new JiebaSegmenter();
			htmlStr = getString(segmenter.sentenceProcess(htmlStr));

			textStr = htmlStr;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return textStr;
	}

	public static String getString(List<String> str) {
		String s = "";
		for (int i = 0; i < str.size(); i++) {
			s += str.get(i) + " ";
		}
		return s;
	}
	/*
	 * String line = ""; String everyLine = ""; line = br.readLine(); everyLine =
	 * br.readLine(); System.out.println(line); System.out.println(everyLine);
	 * br.close();
	 */

}

/*
 * public static void getURLFile(String urlname, String filelocation) { URL url
 * = null; try { // url = new
 * URL("https://item.taobao.com/item.htm?id=573814949424"); //��Ҫ��ȡ��url��ַ url =
 * new URL(urlname); File fp = new File(filelocation); OutputStream os = new
 * FileOutputStream(fp); // �����ļ������ URLConnection conn = url.openConnection();
 * // ��url���� BufferedReader in = new BufferedReader(new
 * InputStreamReader(conn.getInputStream())); String urlString = ""; String
 * current; while ((current = in.readLine()) != null) { //
 * System.out.println(current); current = stripHtml(current);
 * System.out.println(current); urlString += current; }
 * os.write(urlString.getBytes()); os.flush(); os.close();
 * 
 * } catch (MalformedURLException e) { e.printStackTrace(); } catch (IOException
 * e) { e.printStackTrace(); }
 * 
 * } public static String stripHtml(String HTMLStr) {
 * 
 * String htmlStr = HTMLStr; String textStr = "";
 * 
 * java.util.regex.Pattern p_script; java.util.regex.Matcher m_script;
 * java.util.regex.Pattern p_style; java.util.regex.Matcher m_style;
 * java.util.regex.Pattern p_html; java.util.regex.Matcher m_html;
 * java.util.regex.Pattern p_o; java.util.regex.Matcher m_o; try {
 * 
 * String regEx_o = " ";//�ո� p_o = Pattern.compile(regEx_o,
 * Pattern.CASE_INSENSITIVE); m_o = p_o.matcher(htmlStr); htmlStr =
 * m_o.replaceAll(" ");
 * 
 * regEx_o = "<\\/p>";//���з� p_o = Pattern.compile(regEx_o,
 * Pattern.CASE_INSENSITIVE); m_o = p_o.matcher(htmlStr); htmlStr =
 * m_o.replaceAll("</p>;newline;");
 * 
 * // regEx_o = "<\\!--.*-->";//htmlע�� regEx_o = "<!--.[^-]*(?=-->)-->";//htmlע��
 * p_o = Pattern.compile(regEx_o, Pattern.CASE_INSENSITIVE); m_o =
 * p_o.matcher(htmlStr); htmlStr = m_o.replaceAll("");
 * 
 * 
 * String regEx_script =
 * "<[//s]*?script[^>]*?>[//s//S]*?<[//s]*?///[//s]*?script[//s]*?>"; //�ű�
 * p_script = Pattern.compile(regEx_script, Pattern.CASE_INSENSITIVE); m_script
 * = p_script.matcher(htmlStr); htmlStr = m_script.replaceAll("");
 * 
 * String regEx_style =
 * "<[//s]*?style[^>]*?>[//s//S]*?<[//s]*?///[//s]*?style[//s]*?>"; //��ʽ p_style
 * = Pattern.compile(regEx_style, Pattern.CASE_INSENSITIVE); m_style =
 * p_style.matcher(htmlStr); htmlStr = m_style.replaceAll("");
 * 
 * // regEx_o = " ";//�ո� regEx_o = "\\s";//�ո� p_o = Pattern.compile(regEx_o,
 * Pattern.CASE_INSENSITIVE); m_o = p_o.matcher(htmlStr); htmlStr =
 * m_o.replaceAll(" ");
 * 
 * regEx_o = "<\\/p>";//���з� p_o = Pattern.compile(regEx_o,
 * Pattern.CASE_INSENSITIVE); m_o = p_o.matcher(htmlStr); htmlStr =
 * m_o.replaceAll("</p>;newline;");
 * 
 * 
 * String regEx_html = "<[^>]+>"; //����html��ǩ p_html =
 * Pattern.compile(regEx_html, Pattern.CASE_INSENSITIVE); m_html =
 * p_html.matcher(htmlStr); htmlStr = m_html.replaceAll("");
 * 
 * textStr = htmlStr.replaceAll(" ", ""); textStr =
 * textStr.replaceAll(";newline;","\n"); } catch (Exception e) {
 * System.err.println("Html2Text: " + e.getMessage()); } return textStr; } }
 */
