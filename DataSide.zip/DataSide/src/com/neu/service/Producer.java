package com.neu.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;	

import org.apache.kafka.clients.producer.KafkaProducer;
//import org.apache.hadoop.fs.Path;
import org.apache.kafka.clients.producer.ProducerRecord;
//import scala.io.Source;

public class Producer {
	
	  public static void main(String[] args) throws FileNotFoundException, IOException, InterruptedException {
		
		ArrayList<String> list = new ArrayList<String>();
	    String BROKER_LIST = "172.17.11.140:9092,172.17.11.142:9092,172.17.11.143:9092";
	    
	    /**
	     * 1、配置属性
	     * metadata.broker.list : kafka集群的broker
	     * serializer.class : 如何序列化发送消息s
	     * request.required.acks : 1代表需要broker接收到消息后acknowledgment,默认是0
	     * producer.type : async/sync 默认就是同步sync
	     */
	    Properties props = new Properties();
	    props.put("bootstrap.servers", BROKER_LIST);
	    props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
	    props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
	    props.put("request.required.acks", "1");
	    props.put("producer.type", "async");

	    @SuppressWarnings("resource")
		KafkaProducer<String,String> producer = new KafkaProducer<String,String>(props);
	    
	    System.out.println("开始生产消息！！！！！！！！！！");
	    WebPageSource ws = new WebPageSource();
	    list = ws.myPrint("http://www.sohu.com/");
	    
//	    String china = "[\u4e00-\u9fa5]";//汉字的字符集
//	    Pattern pattern = Pattern.compile(china);
	    
	    while (true) {
//	      val files = Source.fromFile("H:\\data\\file"+i)
	      for(String str:list) {
	      try {
	    	  String[] ss = str.split("-");
	    	  StringTokenizer tokenizer = new StringTokenizer(ss[1]);
//	    	  Matcher matcher = pattern.matcher(ss[1]);
//	    	  System.out.println(ss[0]);
//	          System.out.println(ss[1]);
	          
//	          System.out.println(111);
	    	  if(null==ss[1])
	    		  continue;
	    	  while (tokenizer.hasMoreTokens()) {
		      String label = tokenizer.nextToken();  
	    	  ProducerRecord<String, String> record = new ProducerRecord<String, String>("test",label+";"+ss[0]);
	    	  
//	          m = m + 1;
	          System.out.println(record);
//	          System.out.println(ss[1]);
	          producer.send(record);
	          System.out.println();
	    	  }
	          try {
	            Thread.sleep(5000);
	          } catch(Exception e) {
	            e.getStackTrace();
	          }

	        } catch(Exception e1) {
	        e1.getStackTrace();
	      }
	    }
	  }
	}
}
